#!/bin/bash
wget $1 -O download.csv
head -n 1 download.csv > datain.csv
tail -n 10 download.csv >> datain.csv
~/anaconda3/bin/python IWN-ingest.py datain.csv $2
